<?php

return [
    'name' => 'Deviceregistration'
];
